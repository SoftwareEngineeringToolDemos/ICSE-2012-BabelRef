<?php

if (isset($_REQUEST['user']))
	include 'Greetings.php';

$form_name = 'loginform';
$newScript = '<script type="text/javascript">
			function loadPage() { // Sets username input\'s length
				var input = document.' . $form_name . '.user;
				input.setAttribute("maxlength", 20);
			}
		</script>';

if ($_REQUEST['role'] == 'admin') 
	$input = '<input name="NewUser" type="text" style="color:blue;" />';
else
	$input = '<input name="NewUser" type="text" style="color:green;" />';

echo $input;
echo '<html>
	<head>
		' . $newScript . '
	</head>
	<body onload="loadPage();">
		<form name="loginform">
			<label>Enter your name here:</label>
			' . $input . '
			<input type="submit" value="Submit" />
		</form>
	</body>
</html>';

?>
