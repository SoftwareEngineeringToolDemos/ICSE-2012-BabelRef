<html>
<head>
<script type="text/javascript">

function OnSubmit(){
	var submitButton = document.getElementById("NewSubmitButton");
}
</head>
</script>
<body>
<form name="form1">
    <button id="NewSubmitButton">
	</button>
</form>
</body>
</html>
